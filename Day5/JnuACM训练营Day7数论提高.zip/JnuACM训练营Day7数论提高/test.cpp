void init()//Ԥ����������mu 
{
    mu[1]=1;isp[1]=1;sum[0]=0;
    for(int i=2;i<maxn;i++)
    {
        if(isp[i]==0)pri[++p]=i,mu[i]=-1;
        for(int j=1;j<=p&&i*pri[j]<maxn;j++)
        {
            isp[i*pri[j]]=1;
            if(i%pri[j]==0)
            {
                mu[i*pri[j]]=0;//������������ӵ��¹��ױ��0 
                break;
            }
            else mu[i*pri[j]]=-mu[i];   
        }   
    }   
} 
ll qmod(ll a,ll b,int mod)
{
	ll res=1;while(b)
	{
		if(b&1)res=res*a%mod;
		a=a*a%mod;b=b>>1;
	}return res;
} 
