//���⣺a%1+a%2+.....a%a  a<=1e12 
//˼·�������ֿ� 
#include<bits/stdc++.h>
#define ll long long
using namespace std;
const ll mod=1e9+7;
ll sum(ll x)
{
	ll inv2=(1+mod)/2;
	x%=mod;
	return (1+x)*x%mod*inv2%mod; 
} 
int main()
{
	ll n;cin>>n;
	ll ans=0;
	ll nxt=1;
	for(ll i=1;i<=n;i=nxt+1)
	{
		nxt=n/(n/i);
		ans+= 1ll*(n/i)%mod*(sum(nxt)-sum(i-1)+mod)%mod;	
		ans=(ans+mod)%mod;
	}	
	n%=mod;
	cout<<(n*n%mod-ans+mod)%mod<<endl;
} 
