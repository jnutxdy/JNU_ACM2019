#include<bits/stdc++.h>
#define ll long long
using namespace std; 
int pri[2000005];bool isp[20000005];
int mu[20000005];int fuck[20000005];
int sum[20000005];
const int mod=998244353;
void init(int n)
{
    int p=0;mu[1]=1;fuck[1]=1;
    for(int i=2;i<=n;i++)
    {
        if(isp[i]==0)  pri[++p]=i,mu[i]=-1,fuck[i]=-2;
        for(int j=1;j<=p&&i*pri[j]<=n;j++)
        {
            isp[i*pri[j]]=1;
            if(i%pri[j]==0)//�����ʣ�������С������pj�Ĺ��� 
            {
                mu[i*pri[j]]=0;
                int x=i/pri[j];
                if(x%pri[j]!=0)fuck[i*pri[j]]=fuck[x];
                else fuck[i*pri[j]]=0;
                break;
            }
            else mu[i*pri[j]]=-mu[i],fuck[i*pri[j]]=fuck[i]*fuck[pri[j]];//���ʣ�ֱ�Ӹ� 
        }
        //(fuck[i]+=1ll*fuck[i-1]%pp)%=pp; wa
    }
    sum[0]=0;
    for(int i=1;i<=n;i++) sum[i]=fuck[i]+sum[i-1],sum[i]=(sum[i]+mod)%mod;
}
int main()
{
	ll ans=0,nxt=1;
	ll n;scanf("%lld",&n);
	init(n+5);
	for(int i=1;i<=n;i=nxt+1)
	{
		nxt=n/(n/i);
		ans=(ans+(n/i)*(n/i)%mod*(sum[nxt]-sum[i-1]+mod)%mod      )%mod;
	}
	printf("%lld\n",ans);
}

