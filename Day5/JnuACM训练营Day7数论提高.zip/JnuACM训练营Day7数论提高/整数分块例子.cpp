#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
	ll n;cin>>n;
	ll ans=0,nxt=1;
	for(int i=1;i<=n;i=nxt+1)
	{
		nxt=n/(n/i);
		ans+=(nxt-i+1)*(n/i);
	}
	 cout<<ans<<endl;
}
